
{
    'name': 'Reception',
    'author': 'BI solutions',
    'depends': ['base','note'],
    'application': 'True',
    'data': ['views/views.xml','views/menus.xml',],

}
