{
'name': 'qmgnt_app',
'description': 'Quality management',
'author': 'Subhash GC',
'depends': ['base','product'],
'data': [
'views/qmgnt_menu.xml',
'views/dashboard_view.xml',
'views/qmgnt_view.xml',
'views/qmgnt_view1.xml',
'views/qmgnt_view2.xml'


],

'application': True,
}
